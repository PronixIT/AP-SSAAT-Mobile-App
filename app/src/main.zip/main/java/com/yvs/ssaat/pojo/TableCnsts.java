package com.yvs.ssaat.pojo;

/**
 * Created by surya on 12/7/2017.
 */

public class TableCnsts {
    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTicknumber() {
        return ticknumber;
    }

    public void setTicknumber(String ticknumber) {
        this.ticknumber = ticknumber;
    }

    private String ticknumber;
}
